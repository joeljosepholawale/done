import smtplib
from email.message import EmailMessage
from string import Template
from pathlib import Path

html = Template(Path('./index.html').read_text())
urlFile = open("mailist.txt", "r+")
email = EmailMessage()
email['from'] = '"Blockchain" <christian@sme.prefeitura.sp.gov.br>'
email['to'] = mailList = [i.strip() for i in urlFile.readlines()]

email['subject'] = 'Transaction recieved  '

# you can use a list of names and other variables to create custom emails
email.set_content(html.substitute({'name': 'INSTERT_NAME'}), 'html')

with smtplib.SMTP(host='smtp-mail.outlook.com', port=587) as smtp:
    smtp.ehlo()
    smtp.starttls()
    smtp.login('christian@sme.prefeitura.sp.gov.br', 'Argentina01')
    smtp.send_message(email)
    print('all good boss!')
